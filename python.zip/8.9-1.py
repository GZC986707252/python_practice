for i in range(1,5):
    print(' '*(4-i),end="")
    print('*'*(2*i-1))
for j in range(1,4):
    print(' '*j,end="")
    print('*'*(7-2*j))

'''
for i in range(1, 5):
	print(' ' * (4 - i), end="")
	for j in range(1, 2 * i):
		print('*', end="")
	print()
for i in range(3, 0, -1):
	print(' ' * (4 - i), end="")
	for j in range(1, 2 * i):
		print('*', end="")
	print()
'''
